import streamlit as st
from transformers import AutoImageProcessor, AutoModelForImageClassification
from PIL import Image
import torch
import torch.nn.functional as F  # For softmax

# Load the model only once when the app starts
@st.cache_resource
def load_model():
    processor = AutoImageProcessor.from_pretrained("DhruvJariwala/deepfake_vs_real_image_detection")
    model = AutoModelForImageClassification.from_pretrained("DhruvJariwala/deepfake_vs_real_image_detection")
    return processor, model

def main():
    # Load the model
    processor, model = load_model()

    # Sidebar for additional information or instructions
    st.sidebar.image("capgemini_smalllogo.jpg", use_container_width=True)  # Replace with your logo URL
    st.sidebar.title("Deepfake Detector")
    st.sidebar.subheader("version 1.1", divider=True)
    st.sidebar.write("Upload an image to detect if it's real or suspicious.")

    # Allow the user to upload an image
    uploaded_image = st.file_uploader("Upload an image", type=["jpg", "jpeg", "png"])

    # Button to trigger prediction
    if uploaded_image is not None:
        # Show a preview of the uploaded image
        st.image(uploaded_image, caption="Uploaded Image", width=200)

        # Create a button to perform prediction
        predict_button = st.button("Predict")

        if predict_button:
            # Open the uploaded image
            image = Image.open(uploaded_image)

            # Preprocess the image
            inputs = processor(images=image, return_tensors="pt")

            # Perform inference
            with torch.no_grad():
                outputs = model(**inputs)

            # Get the predicted class index and logits
            logits = outputs.logits
            predicted_class_idx = logits.argmax(-1).item()

            # Apply softmax to get probabilities
            probabilities = F.softmax(logits, dim=-1)

            # Get the confidence score of the predicted class
            confidence_score = probabilities[0, predicted_class_idx].item() * 100  # Confidence as percentage

            # Labels based on your model's output (ensure these match your model's actual labels)
            labels = ["Real", "Suspicious"]
            predicted_label = labels[predicted_class_idx]

            # Display the prediction result and confidence score
            st.subheader(f"Prediction: {predicted_label}")
            st.write(f"Confidence: {confidence_score:.2f}%")

if __name__ == "__main__":
    main()
